# Xpress Feeder Airline - WebSocket Server Documentation

## Overview
Central WebSocket server for real-time notifications across all departments of Xpress Feeder Airline operations system.

## Directory Structure
